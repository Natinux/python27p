# The version and main description string for Stand-Alone Python Interpreter

Version = "2.7.9.10"
Description = "Stand-Alone Python Interpreter"

